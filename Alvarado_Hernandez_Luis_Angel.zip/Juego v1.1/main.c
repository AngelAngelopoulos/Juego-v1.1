#include <graphics.h>
#include <stdlib.h>
#include <stdio.h>
#include <windows.h>
#include "GRID.h"
#include "MENU.h"

int main()
{
    void *bitmap;
    int res = 0, resp = 0;
    //About();
    res = Menu();
    if (res == 6)
    {
        do{
            //setvisualpage(0);
        //setactivepage(1);
        //NODE_STAGE stage1, stage2, stage3, stage4;
        NODE_STAGE stages[4];
        initwindow(1152, 672, "Hola");

        initStages(&stages[0]);
        initStages(&stages[1]);
        initStages(&stages[2]);
        initStages(&stages[3]);

        createNodeStage(&stages[0], "stage1");
        createNodeStage(&stages[1], "stage2");
        createNodeStage(&stages[2], "stage3");
        createNodeStage(&stages[3], "stage4");

        loadGridStage(&stages[0]->listSprites, stages[0]);
        loadGridStage(&stages[1]->listSprites, stages[1]);
        loadGridStage(&stages[2]->listSprites, stages[2]);
        loadGridStage(&stages[3]->listSprites, stages[3]);


        //impStage(stages[0]->listSprites, stages[0], 0, 0, 0, 1);
        stages[0]->bitmap1 = (void*)malloc(imagesize(0, 0, 960, 672)); //Cuadrante 1
        getimage(0,0,960,672, stages[0]->bitmap1);
        cleardevice();

        /*impStage(stage1->listSprites, stage1, 0, 0, 0, 6);
        stage1->bitmap2 = (void*)malloc(imagesize(0, 0, 960, 672));  //Cuadrante 2
        getimage(0,0,960,672, stage1->bitmap2);
        cleardevice();

        impStage(stage1->listSprites, stage1, 0, 0, 9, 0);
        stage1->bitmap3 = (void*)malloc(imagesize(0, 0, 960, 672));  //Cuadrante 3
        getimage(0, 0, 960, 672, stage1->bitmap3);
        cleardevice();

        impStage(stage1->listSprites, stage1, 0, 0, 9, 6);
        stage1->bitmap4 = (void*)malloc(imagesize(0, 0, 960, 672));  //Cuarante 4
        getimage(0, 0, 960, 672, stage1->bitmap4);
        cleardevice();*/

        //putimage(0, 0, stages[0]->bitmap1, XOR_PUT);
        loadGridStage(&stages[0]->listSprites, stages[0]);
        impBarraEstado(stages[0], 0);
        //setvisualpage(1);
        resp = Juega(stages);
        escRec();
        }while(resp == 1);
    }
    //getch();
}
